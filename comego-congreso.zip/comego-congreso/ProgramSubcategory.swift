//
//  ProgramSubcategory.swift
//  comego
//
//  Created by Jonathan Horta on 5/25/18.
//  Copyright © 2018 iddeas. All rights reserved.
//

import Foundation
class ProgramSubcategory:NSObject{
    var id:Int = 0
    var title:String = ""
    var activities = [ProgramItem]()
}
