//
//  MyScheduleItem.swift
//  flasog
//
//  Created by Jonathan Horta on 9/17/17.
//  Copyright © 2017 iddeas. All rights reserved.
//

import Foundation
class MyScheduleItem:NSObject{
    var catId:Int = 0
    var id:Int = 0
    var title:String = ""
    var subtitle:String = ""
    var schedule:String = ""
    //var items:[ProgramItem] = []
}
