//
//  PodcastPart.swift
//  comego
//
//  Created by Jonathan Horta on 5/23/18.
//  Copyright © 2018 iddeas. All rights reserved.
//

import Foundation

class PodcastPart:NSObject{
    var title:String = ""
    var url:String = ""
}
